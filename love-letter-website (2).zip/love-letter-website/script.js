const $ = (id) => document.getElementById(id);
const content = SITE_CONTENT;
$("herName").textContent = content.herName;
$("yourName").textContent = content.yourName;
$("letterText").textContent = content.letter;
if (content.musicFile) $("backgroundMusic").src = `assets/music/${content.musicFile}`;

$("enterButton").addEventListener("click", () => {
  $("welcome").classList.add("hidden");
  $("letterScreen").classList.remove("hidden");
  window.scrollTo(0,0);
});
$("continueButton").addEventListener("click", () => {
  $("letterScreen").classList.add("hidden");
  $("app").classList.remove("hidden");
  window.scrollTo(0,0);
});
function showTab(name){
  document.querySelectorAll(".tab-panel").forEach(p=>p.classList.toggle("active-panel",p.id===name));
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.go)));
document.querySelector(".brand").addEventListener("click",e=>{e.preventDefault();showTab("home")});

$("musicToggle").addEventListener("click",async()=>{
  const audio=$("backgroundMusic");
  if(!audio.src){alert("Add your MP3 filename to musicFile in content.js, then put the MP3 in assets/music/.");return;}
  if(audio.paused){try{await audio.play();$("musicToggle").innerHTML="♫ <span>Pause music</span>";}catch(e){alert("Your browser couldn't play the music file.");}}
  else{audio.pause();$("musicToggle").innerHTML="♫ <span>Play our song</span>";}
});

// Memory timeline
const timeline=$("timeline");
content.memories.forEach((m,i)=>{
  const card=document.createElement("article");card.className="memory-card";
  const date=document.createElement("div");date.className="memory-date";date.textContent=m.date;
  const title=document.createElement("h3");title.textContent=m.title;
  const caption=document.createElement("p");caption.textContent=m.caption;
  const feeling=document.createElement("p");feeling.className="memory-feeling";feeling.textContent=m.feeling;
  card.append(date,title,caption);
  if(m.image){const img=document.createElement("img");img.src=m.image;img.alt=m.title;img.loading="lazy";card.append(img);}
  card.append(feeling);card.addEventListener("click",()=>card.classList.toggle("expanded"));timeline.append(card);
});

// Drawing game
const canvas=$("drawingCanvas"),ctx=canvas.getContext("2d");
ctx.lineCap="round";ctx.lineJoin="round";ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height);
let drawing=false,last=null;
function point(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height};}
canvas.addEventListener("pointerdown",e=>{drawing=true;last=point(e);canvas.setPointerCapture(e.pointerId);});
canvas.addEventListener("pointermove",e=>{if(!drawing)return;const p=point(e);ctx.strokeStyle=$("penColor").value;ctx.lineWidth=+$("penSize").value;ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p;});
canvas.addEventListener("pointerup",()=>drawing=false);canvas.addEventListener("pointercancel",()=>drawing=false);
function clearCanvas(){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height);}
$("undoDrawing").addEventListener("click",clearCanvas);
function newPrompt(){const p=content.drawingPrompts[Math.floor(Math.random()*content.drawingPrompts.length)];$("drawPrompt").textContent=p;}
$("newPrompt").addEventListener("click",newPrompt);
$("saveDrawing").addEventListener("click",()=>{const a=document.createElement("a");a.download="my-masterpiece.png";a.href=canvas.toDataURL("image/png");a.click();$("drawingMessage").textContent="Saved! Your masterpiece is officially art. ♡";});

// Quiz
let quizIndex=0,score=0,answered=false;
function renderQuestion(){
  const q=content.quiz[quizIndex];answered=false;
  $("quizCount").textContent=`Question ${quizIndex+1} of ${content.quiz.length}`;
  $("quizScore").textContent=`♡ ${score}`;
  $("questionText").textContent=q.question;$("quizFeedback").textContent="";
  $("nextQuestion").disabled=true;$("nextQuestion").textContent=quizIndex===content.quiz.length-1?"See my score ♡":"Next question →";
  const wrap=$("answerOptions");wrap.innerHTML="";
  q.options.forEach(option=>{
    const b=document.createElement("button");b.className="answer-option";b.textContent=option;
    b.addEventListener("click",()=>{
      if(answered)return;answered=true;
      const correct=option===q.answer;if(correct){score++;b.classList.add("correct");$("quizFeedback").textContent="You got it! You know me so well. ♡";}
      else{$("quizFeedback").textContent=`Not quite! The answer is: ${q.answer} ♡`;[...wrap.children].forEach(x=>{if(x.textContent===q.answer)x.classList.add("correct");});b.classList.add("wrong");}
      $("quizScore").textContent=`♡ ${score}`;$("nextQuestion").disabled=false;
    });wrap.append(b);
  });
}
$("nextQuestion").addEventListener("click",()=>{if(!answered)return;if(quizIndex<content.quiz.length-1){quizIndex++;renderQuestion();}else{$("questionText").textContent=`You got ${score} out of ${content.quiz.length}!`; $("answerOptions").innerHTML="";$("quizFeedback").textContent="No matter the score, you're my favorite person. ♡";$("nextQuestion").textContent="Play again ↻";$("nextQuestion").disabled=false;$("nextQuestion").onclick=()=>{quizIndex=0;score=0;$("nextQuestion").onclick=null;renderQuestion();};}});
renderQuestion();

// Drag-and-drop picture game
const pieces=$("puzzlePieces"),slots=[...document.querySelectorAll(".drop-slot")];
function mix(a){return a.sort(()=>Math.random()-.5);}
function setupPuzzle(){
  pieces.innerHTML="";slots.forEach(s=>{s.innerHTML="<span>DROP HERE</span>";s.dataset.filled="false";});
  mix([...content.puzzleImages]).forEach((file,i)=>{
    const img=document.createElement("img");img.src=`assets/puzzle/${file}`;img.alt=`Picture piece ${i+1}`;
    img.onerror=()=>{img.style.display="none";const fallback=document.createElement("div");fallback.style.cssText="height:100%;display:grid;place-items:center;background:#f9e7ed;color:#a45c77;font-size:12px;text-align:center;padding:6px";fallback.textContent=`Add ${file} here`;img.parentElement?.append(fallback);};
    const piece=document.createElement("div");piece.className="puzzle-piece";piece.draggable=true;piece.dataset.file=file;piece.append(img);
    piece.addEventListener("dragstart",e=>{e.dataTransfer.setData("text/plain",file);});
    pieces.append(piece);
  });
  slots.forEach((slot,i)=>{
    slot.addEventListener("dragover",e=>{e.preventDefault();slot.classList.add("over");});
    slot.addEventListener("dragleave",()=>slot.classList.remove("over"));
    slot.addEventListener("drop",e=>{
      e.preventDefault();slot.classList.remove("over");const file=e.dataTransfer.getData("text/plain");if(!file||slot.dataset.filled==="true")return;
      const piece=[...pieces.children].find(p=>p.dataset.file===file);if(!piece)return;
      slot.innerHTML="";const clone=piece.querySelector("img").cloneNode();clone.style.display="";slot.append(clone);slot.dataset.filled="true";piece.style.visibility="hidden";
      if(slots.every(s=>s.dataset.filled==="true"))$("puzzleMessage").textContent="YOU DID IT! 10/10 adorable. ♡";
    });
  });
  $("puzzleMessage").textContent="Drag each picture into a frame. ♡";
}
$("resetPuzzle").addEventListener("click",setupPuzzle);setupPuzzle();
