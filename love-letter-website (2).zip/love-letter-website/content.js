/*
  EDIT THIS FILE TO PERSONALIZE THE WEBSITE.
  Put your photos in assets/photos/ and update each image path below.
  Put a calm romantic MP3 in assets/music/ and set MUSIC_FILE to its filename.
*/
const SITE_CONTENT = {
  herName: "Vrila",
  yourName: "Carlo",
  letter: `I don't even know where to begin, because there are so many things I want you to know.

  You make ordinary days feel special. I'm grateful for every laugh, every conversation, every little moment we get to share. I made this tiny website as a place to keep some of those moments and remind you how much you mean to me.

  I hope it makes you smile. And I hope you always remember that you are loved — more than words can properly explain.

  I love you, always. ♡`,
  // Add your own audio file to assets/music/ and enter its exact filename here.
  musicFile: "",
  memories: [
    { date:"Memory 01", title:"A little moment with Vrila", image:"assets/photos/memory-01.jpeg", caption:"Add a short caption for this photo here.", feeling:"Carlo can add what he felt in this moment later." },
    { date:"Memory 02", title:"A little moment with Vrila", image:"assets/photos/memory-02.jpeg", caption:"Add a short caption for this photo here.", feeling:"Carlo can add what he felt in this moment later." },
    { date:"Memory 03", title:"A little moment with Vrila", image:"assets/photos/memory-03.jpeg", caption:"Add a short caption for this photo here.", feeling:"Carlo can add what he felt in this moment later." },
    { date:"Memory 04", title:"A little moment with Vrila", image:"assets/photos/memory-04.jpeg", caption:"Add a short caption for this photo here.", feeling:"Carlo can add what he felt in this moment later." },
    { date:"Memory 05", title:"A little moment with Vrila", image:"assets/photos/memory-05.jpeg", caption:"Add a short caption for this photo here.", feeling:"Carlo can add what he felt in this moment later." },
    { date:"Memory 06", title:"A little moment with Vrila", image:"assets/photos/memory-06.jpeg", caption:"Add a short caption for this photo here.", feeling:"Carlo can add what he felt in this moment later." }
  ],
  quiz: [
    { question:"When did we get together?", options:["7 August 2026","14 February 2026","1 January 2026","25 December 2025"], answer:"7 August 2026" },
    { question:"Where did we see each other again after a few years?", options:["At school","At Lippo, by accident","At a concert","At the beach"], answer:"At Lippo, by accident" },
    { question:"What's my favorite animal?", options:["Dog","Cat","Rabbit","Penguin"], answer:"Cat" },
    { question:"What's my favorite color?", options:["Blue","Red","Green","Purple"], answer:"Green" },
    { question:"How much do I love you?", options:["A little bit","A lot","100%","More than 100% — infinity"], answer:"100%" },
    { question:"What's the best thing about us?", options:["Everything","Our laughs","Our memories","All of the above"], answer:"All of the above" }
  ],
  drawingPrompts: [
    "A cat wearing a flower crown","A frog having a tea party","A tiny house shaped like a strawberry",
    "A sleepy bunny on the moon","A dinosaur holding a bouquet","A penguin in a fancy suit",
    "A heart-shaped cloud with a face","A dog riding a bicycle","A magical garden"
  ],
  // Add three images to assets/puzzle/ and enter their filenames.
  puzzleImages: ["piece-1.jpg","piece-2.jpg","piece-3.jpg"]
};
