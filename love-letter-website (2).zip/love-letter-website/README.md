# Our Little Love Website ♡

A pink, vintage love-scrapbook mini-website made with plain HTML, CSS and JavaScript. It works on phones and computers and can be hosted free with GitHub Pages.

## Personal details already added\n- Her nickname: Vrila\n- Sign-off: Carlo\n- Style: vintage pink love scrapbook\n\n## 1. Personalize it

Open `content.js` in a text editor or GitHub and change:
- `herName` and `yourName`
- `letter` — the message shown after the envelope opens
- `memories` — add dates, titles, captions, image paths, and your feelings
- `quiz` — add/edit questions, answer choices, and the correct answer
- `drawingPrompts` — add your own random drawing ideas
- `puzzleImages` — filenames for your three silly pictures
- `musicFile` — exact MP3 filename, e.g. `"our-song.mp3"`

## 2. Add your pictures and music

- Timeline photos go in `assets/photos/`. In `content.js`, set a memory's `image` to e.g. `"assets/photos/first-date.jpg"`.
- The silly drag-and-drop game uses exactly three pictures in `assets/puzzle/`. Replace the sample filenames `piece-1.jpg`, `piece-2.jpg`, `piece-3.jpg` with your filenames.
- Put an MP3 you have permission to use in `assets/music/`, then set `musicFile` in `content.js`. Browsers require a tap before music can play, so she can start it with the music button.

Keep filenames simple (letters, numbers, hyphens; avoid unusual symbols).

## 3. Put it on GitHub Pages

1. Create or sign in to a GitHub account.
2. Create a new **Public** repository, for example `for-her`.
3. Upload the contents of this folder (the files inside it, not an extra nested folder).
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then Save.
7. Wait a minute or two. GitHub will show your website URL in the Pages section.

## Notes

- No build tools or installation are required.
- The envelope, navigation tabs, timeline, drawing canvas, quiz, and drag/drop game work as a static site.
- The drawing game lets her save her drawing as a PNG.
- This is a starter template: once you send your photos and your actual letter, they can be added and the placeholders replaced.


## Photos already added
Six uploaded photos have been copied into `assets/photos/` as `memory-01.jpeg` through `memory-06.jpeg` and added to the timeline. Their titles, dates, captions, and personal notes are starter placeholders, ready to be edited later in `content.js` or by asking ChatGPT to update the project.
